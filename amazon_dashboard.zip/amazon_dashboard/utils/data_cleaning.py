# data_cleaning.py
from datetime import datetime
import pandas as pd
import numpy as np
import re

# ---------------- Helper Functions ----------------

def parse_order_date(s):
    """Parse order_date from multiple formats to pd.Timestamp, invalids -> NaT."""
    if pd.isna(s):
        return pd.NaT
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%m/%d/%Y", "%d/%m/%y", "%d-%m-%y"):
        try:
            return pd.to_datetime(s, format=fmt)
        except (ValueError, TypeError):
            continue
    return pd.NaT

def clean_price(x):
    """Extract numeric price from text like '₹1,25,000' or 'Price on Request'."""
    if pd.isna(x):
        return np.nan
    x = str(x).replace('₹', '').replace(',', '').strip()
    try:
        val = float(x)
        return val if val >= 0 else np.nan  # Remove negative prices
    except:
        return np.nan

def clean_rating(x):
    """Standardize ratings to float 1.0 - 5.0."""
    if pd.isna(x):
        return np.nan
    x = str(x).lower().strip()
    match = re.search(r'(\d+(\.\d+)?)', x)
    if match:
        val = float(match.group(1))
        return min(max(val, 1.0), 5.0)
    return np.nan

def clean_boolean(x):
    """Convert mixed boolean formats to True/False."""
    if pd.isna(x):
        return False
    x = str(x).strip().lower()
    return x in ['true', 'yes', '1', 'y', 't']

def clean_category(x):
    """Standardize product categories."""
    if pd.isna(x):
        return 'Unknown'
    x = str(x).lower()
    x = re.sub(r'&', 'and', x)
    if 'electronic' in x:
        return 'Electronics'
    elif 'fashion' in x:
        return 'Fashion'
    elif 'home' in x:
        return 'Home & Kitchen'
    else:
        return x.title()

def clean_delivery_days(x):
    """Convert delivery days to numeric."""
    if pd.isna(x):
        return np.nan
    if isinstance(x, str):
        x = x.lower().strip()
        if 'same' in x:
            return 0
        if '-' in x:
            parts = re.findall(r'\d+', x)
            if parts:
                return int(np.mean([int(p) for p in parts]))
        else:
            try:
                return int(re.search(r'\d+', x).group())
            except:
                return np.nan
    try:
        val = int(x)
        return val if 0 <= val < 30 else np.nan
    except:
        return np.nan

def clean_payment(x):
    """Standardize payment method names."""
    if pd.isna(x):
        return 'Unknown'
    x = str(x).lower()
    if 'upi' in x or 'phonepe' in x or 'google' in x:
        return 'UPI'
    elif 'credit' in x or 'cc' in x:
        return 'Credit Card'
    elif 'cash' in x or 'cod' in x:
        return 'Cash on Delivery'
    else:
        return x.title()

def clean_city(x):
    """Standardize customer city names."""
    if pd.isna(x):
        return 'Unknown'
    x = str(x).lower().strip()
    mapping = {'bangalore': 'Bengaluru', 'bombay': 'Mumbai', 'new delhi': 'Delhi'}
    x = mapping.get(x, x)
    return x.title()

# ---------------- Main Cleaning Function ----------------

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()  # work on a copy

    # --- Dates ---
    if 'order_date' in df.columns:
        df['order_date'] = df['order_date'].apply(parse_order_date)
        df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')
        # Only access .dt for datetime-like values
        df['order_year'] = df['order_date'].dt.year.astype('Int64', errors='ignore')
        df['order_month'] = df['order_date'].dt.month.astype('Int64', errors='ignore')
        df['order_quarter'] = df['order_date'].dt.quarter.astype('Int64', errors='ignore')
        # Optional: filter unrealistic years
        df = df[df['order_year'].between(2000, 2030) | df['order_year'].isna()]

    # --- Prices ---
    if 'original_price_inr' in df.columns:
        df['original_price_inr'] = df['original_price_inr'].apply(clean_price)

    # --- Ratings ---
    if 'customer_rating' in df.columns:
        df['customer_rating'] = df['customer_rating'].apply(clean_rating)

    # --- City Names ---
    if 'customer_city' in df.columns:
        df['customer_city'] = df['customer_city'].apply(clean_city)

    # --- Boolean Columns ---
    boolean_cols = ['is_prime_member', 'is_prime_eligible', 'is_festival_sale']
    for col in boolean_cols:
        if col in df.columns:
            df[col] = df[col].apply(clean_boolean)

    # --- Product Categories ---
    if 'product_category' in df.columns:
        df['product_category'] = df['product_category'].apply(clean_category)

    # --- Delivery Days ---
    if 'delivery_days' in df.columns:
        df['delivery_days'] = df['delivery_days'].apply(clean_delivery_days)

    # --- Payment Methods ---
    if 'payment_method' in df.columns:
        df['payment_method'] = df['payment_method'].apply(clean_payment)

    # --- Remove Duplicates ---
    # Drop rows with missing IDs first to avoid incorrect deduplication
    df = df.dropna(subset=['customer_id', 'product_id'])
    df = df.drop_duplicates(subset=['customer_id', 'product_id', 'order_date', 'original_price_inr'])

    # --- Final Missing Value Summary ---
    missing_summary = df.isna().sum()
    print("Missing values per column after cleaning:\n", missing_summary)

    return df
