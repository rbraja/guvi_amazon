# utils/data_loader.py
import os
import pandas as pd
from utils import data_cleaning

RAW_DATA_FOLDER = "data/raw"
CLEAN_DATA_FOLDER = "data/clean"
os.makedirs(CLEAN_DATA_FOLDER, exist_ok=True)

def clean_and_save_once(chunksize=100_000):
    """
    Reads all CSVs from RAW_DATA_FOLDER in chunks, cleans them, and saves a single combined CSV.
    Returns the path to the cleaned CSV.
    """
    combined_file = os.path.join(CLEAN_DATA_FOLDER, "amazon_india_clean.csv")
    
    if os.path.exists(combined_file):
        print(f"✅ Cleaned file already exists: {combined_file}")
        return combined_file

    csv_files = [f for f in os.listdir(RAW_DATA_FOLDER) if f.endswith(".csv")]
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {RAW_DATA_FOLDER}")

    cleaned_chunks = []

    for file in csv_files:
        file_path = os.path.join(RAW_DATA_FOLDER, file)
        print(f"📝 Processing file: {file_path}")
        # Read in chunks to avoid memory errors
        for chunk in pd.read_csv(file_path, chunksize=chunksize):
            clean_chunk = data_cleaning.clean_data(chunk)
            cleaned_chunks.append(clean_chunk)

    # Combine all chunks safely
    combined_df = pd.concat(cleaned_chunks, ignore_index=True)
    combined_df.to_csv(combined_file, index=False)
    print(f"✅ Saved cleaned file: {combined_file}")
    return combined_file
