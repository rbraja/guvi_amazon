import sqlite3
import pandas as pd
import os

DB_PATH = "data/amazon_analytics.db"

# ----------------- Connection -----------------
def get_connection():
    if not os.path.exists("data"):
        os.makedirs("data")
    return sqlite3.connect(DB_PATH)

# ----------------- Table Creation -----------------
def create_tables(drop_existing=False):
    """Create tables with primary keys and indexes."""
    conn = get_connection()
    cursor = conn.cursor()

    if drop_existing:
        cursor.execute("DROP TABLE IF EXISTS transactions;")
        cursor.execute("DROP TABLE IF EXISTS products;")
        cursor.execute("DROP TABLE IF EXISTS customers;")
        cursor.execute("DROP TABLE IF EXISTS time_dimension;")
        conn.commit()

    # Transactions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id TEXT PRIMARY KEY,
            order_date TEXT,
            customer_id TEXT,
            product_id TEXT,
            product_name TEXT,
            category TEXT,
            subcategory TEXT,
            brand TEXT,
            original_price_inr REAL,
            discount_percent REAL,
            discounted_price_inr REAL,
            quantity INTEGER,
            subtotal_inr REAL,
            delivery_charges REAL,
            final_amount_inr REAL,
            customer_city TEXT,
            customer_state TEXT,
            customer_tier TEXT,
            customer_spending_tier TEXT,
            customer_age_group TEXT,
            payment_method TEXT,
            delivery_days REAL,
            delivery_type TEXT,
            is_prime_member TEXT,
            is_festival_sale TEXT,
            festival_name TEXT,
            customer_rating REAL,
            return_status TEXT,
            order_month INTEGER,
            order_year INTEGER,
            order_quarter INTEGER,
            product_weight_kg REAL,
            is_prime_eligible TEXT,
            product_rating REAL
        );
    """)

    # Products table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id TEXT PRIMARY KEY,
            product_name TEXT,
            category TEXT,
            subcategory TEXT,
            brand TEXT
        );
    """)

    # Customers table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id TEXT PRIMARY KEY,
            customer_name TEXT,
            customer_city TEXT,
            customer_state TEXT,
            customer_tier TEXT,
            customer_spending_tier TEXT,
            customer_age_group TEXT,
            is_prime_member TEXT
        );
    """)

    # Time dimension
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS time_dimension (
            date_key TEXT PRIMARY KEY,
            year INTEGER,
            month INTEGER,
            day INTEGER,
            quarter INTEGER
        );
    """)

    conn.commit()
    conn.close()

# ----------------- Run Query -----------------
def run_query(query: str) -> pd.DataFrame:
    """Run a SQL query and return results as a DataFrame."""
    try:
        conn = get_connection()
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df
    except Exception as e:
        return pd.DataFrame({"Error": [str(e)]})

# ----------------- Insert DataFrame -----------------
def insert_dataframe(df: pd.DataFrame, table_name: str):
    """Insert DataFrame; ignore duplicates based on primary key."""
    conn = get_connection()
    df.to_sql(table_name, conn, if_exists='append', index=False, method='multi')
    conn.close()

# ----------------- Insert CSV in Batches -----------------
def insert_csv_in_batches(csv_path, chunksize=50000, batch_size=500):
    """
    Load CSV in chunks and insert in SQLite batches to avoid 
    'too many SQL variables' error.
    """
    for chunk in pd.read_csv(csv_path, chunksize=chunksize):
        chunk = chunk.drop_duplicates(subset=["transaction_id"])
        if chunk.empty:
            continue

        conn = get_connection()
        cursor = conn.cursor()
        columns = list(chunk.columns)
        placeholders = ",".join(["?"] * len(columns))
        sql = f"INSERT OR IGNORE INTO transactions ({','.join(columns)}) VALUES ({placeholders})"

        data = chunk.values.tolist()
        for i in range(0, len(data), batch_size):
            batch = data[i:i+batch_size]
            cursor.executemany(sql, batch)
            conn.commit()
        conn.close()
