# app.py
import streamlit as st
import importlib
import os
import pandas as pd
from utils import data_loader

st.set_page_config(page_title="Amazon India Analytics", layout="wide")
st.title("📊 Amazon India Analytics Dashboard (2015-2025)")

# ---------------- 1️⃣ Clean & Load CSV Path ----------------
with st.spinner("Cleaning/loading data..."):
    combined_csv_path = data_loader.clean_and_save_once(chunksize=100_000)
st.success(f"✅ Data cleaned and saved: {combined_csv_path}")

# ---------------- 2️⃣ Dynamic Page Loader ----------------
pages_folder = "pages"
if not os.path.exists(pages_folder):
    st.warning("⚠️ Pages folder not found! Please create a 'pages' folder.")
else:
    pages = {}
    # ✅ Skip __init__.py and app.py (so "app" doesn’t appear in sidebar)
    page_files = [
        f for f in os.listdir(pages_folder)
        if f.endswith(".py") and f not in ["__init__.py", "app.py"]
    ]

    for file in page_files:
        module_name = file.replace(".py", "")
        try:
            module = importlib.import_module(f"pages.{module_name}")
            title = module_name.replace("_", " ").title()
            pages[title] = module
        except Exception as e:
            st.error(f"❌ Failed to import page {file}: {e}")

    # ---------------- 3️⃣ Sidebar Navigation ----------------
    if pages:
        page_title = st.sidebar.radio("Go to page:", list(pages.keys()))
        try:
            pages[page_title].app(combined_csv_path)
        except Exception as e:
            st.error(f"❌ Error loading page '{page_title}': {e}")
    else:
        st.info("No pages available. Please add Python files to the 'pages' folder.")
