# pages/2_EDA.py
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

sns.set_style("whitegrid")

def app(csv_path: str):
    st.header("📊 20 Essential Business Insights (Amazon Dataset)")

    # ----------------------------
    # Load data safely
    # ----------------------------
    try:
        df = pd.read_csv(csv_path, nrows=100_000)
    except Exception as e:
        st.error(f"❌ Failed to load CSV: {e}")
        return

    # ----------------------------
    # Data type conversions
    # ----------------------------
    df['order_date'] = pd.to_datetime(df['order_date'], errors='coerce')
    df['order_year'] = df['order_date'].dt.year
    df['order_month'] = df['order_date'].dt.month
    df['final_amount_inr'] = pd.to_numeric(df['final_amount_inr'], errors='coerce')
    df['discount_percent'] = pd.to_numeric(df['discount_percent'], errors='coerce')
    df['quantity'] = pd.to_numeric(df['quantity'], errors='coerce')
    df['delivery_days'] = pd.to_numeric(df['delivery_days'], errors='coerce')
    df['product_rating'] = pd.to_numeric(df['product_rating'], errors='coerce')
    df['final_amount_lakh'] = df['final_amount_inr']/1e5

    if 'is_prime_member' in df.columns:
        df['is_prime_member'] = df['is_prime_member'].map({
            'Yes': True, 'Y': True, 1: True,
            'No': False, 'N': False, 0: False,
            True: True, False: False
        }).fillna(False)

    st.subheader("🧾 Sample Data")
    st.dataframe(df.head())

    # ----------------------------
    # Helper plotting functions
    # ----------------------------
    def plot_bar(df_plot, x, y, xlabel, ylabel, title, rotation=0):
        plt.figure(figsize=(8,4))
        sns.barplot(data=df_plot, x=x, y=y, palette="viridis")
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        plt.xticks(rotation=rotation)
        st.pyplot(plt)
        plt.clf()

    def plot_box(df_plot, x, y, xlabel, ylabel, title):
        plt.figure(figsize=(6,4))
        sns.boxplot(x=x, y=y, data=df_plot)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        st.pyplot(plt)
        plt.clf()

    def plot_hist(df_plot, col, xlabel, ylabel, title, bins=20):
        plt.figure(figsize=(6,4))
        sns.histplot(df_plot[col].dropna(), bins=bins, kde=True, color='coral')
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        st.pyplot(plt)
        plt.clf()

    def plot_scatter(df_plot, x, y, xlabel, ylabel, title):
        plt.figure(figsize=(6,4))
        sns.scatterplot(x=x, y=y, data=df_plot, alpha=0.5)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        st.pyplot(plt)
        plt.clf()

    # ----------------------------
    # 1️⃣ Yearly Revenue Trend
    # ----------------------------
    st.subheader("1️⃣ Yearly Revenue Trend")
    st.markdown("""
    **Chart:** Line Chart  
    **Purpose:** Show how total revenue changes each year  
    **X-axis:** Year (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Observe how revenue grows or dips over time.
    """)
    yearly = df.groupby('order_year')['final_amount_lakh'].sum().reset_index()
    plt.figure(figsize=(8,4))
    plt.plot(yearly['order_year'], yearly['final_amount_lakh'], marker='o', color='teal')
    plt.xlabel("Year (Discrete)")
    plt.ylabel("Revenue (₹ Lakh, Continuous)")
    plt.title("Yearly Revenue Trend")
    st.pyplot(plt)
    plt.clf()

    # ----------------------------
    # 2️⃣ Monthly Sales Pattern
    # ----------------------------
    st.subheader("2️⃣ Monthly Sales Pattern")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Show seasonal patterns  
    **X-axis:** Month (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Identify peak sales months.
    """)
    monthly = df.groupby('order_month')['final_amount_lakh'].sum().reset_index()
    plot_bar(monthly, 'order_month', 'final_amount_lakh', 'Month (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Monthly Revenue Pattern')

    # ----------------------------
    # 3️⃣ Top 10 Categories by Revenue
    # ----------------------------
    st.subheader("3️⃣ Top Performing Categories")
    st.markdown("""
    **Chart:** Horizontal Bar Chart  
    **Purpose:** Show best-selling categories  
    **X-axis:** Revenue (₹ Lakh, Continuous)  
    **Y-axis:** Category (Discrete)  
    **Variable Type:** Bivariate  
    **Story:** Identify product types that drive most revenue.
    """)
    cat = df.groupby('category')['final_amount_lakh'].sum().sort_values(ascending=True).tail(10).reset_index()
    plt.figure(figsize=(8,5))
    sns.barplot(x='final_amount_lakh', y='category', data=cat, palette='cool')
    plt.xlabel("Revenue (₹ Lakh, Continuous)")
    plt.ylabel("Category (Discrete)")
    plt.title("Top 10 Categories by Revenue")
    st.pyplot(plt)
    plt.clf()

    # ----------------------------
    # 4️⃣ Payment Methods Distribution
    # ----------------------------
    st.subheader("4️⃣ Payment Methods Usage")
    st.markdown("""
    **Chart:** Count Plot  
    **Purpose:** Compare popularity of payment methods  
    **X-axis:** Payment Method (Discrete)  
    **Y-axis:** Transaction Count (Continuous)  
    **Variable Type:** Univariate  
    **Story:** See rise/fall of UPI, COD, and cards.
    """)
    plt.figure(figsize=(7,4))
    sns.countplot(x='payment_method', data=df, palette='muted')
    plt.xlabel("Payment Method (Discrete)")
    plt.ylabel("Count (Continuous)")
    st.pyplot(plt)
    plt.clf()

    # ----------------------------
    # 5️⃣ Prime vs Non-Prime Spending
    # ----------------------------
    st.subheader("5️⃣ Prime vs Non-Prime Spending")
    st.markdown("""
    **Chart:** Box Plot  
    **Purpose:** Compare order amounts between Prime and Non-Prime  
    **X-axis:** Prime Member (Discrete)  
    **Y-axis:** Final Amount (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Prime members generally spend more.
    """)
    plot_box(df, 'is_prime_member', 'final_amount_lakh', 'Prime Member (Discrete)', 'Final Amount (₹ Lakh, Continuous)', 'Prime vs Non-Prime Spending')

    # ----------------------------
    # 6️⃣ Delivery Days Distribution
    # ----------------------------
    st.subheader("6️⃣ Delivery Days Distribution")
    st.markdown("""
    **Chart:** Histogram  
    **Purpose:** Show how long deliveries take  
    **X-axis:** Delivery Days (Continuous)  
    **Y-axis:** Count (Continuous)  
    **Variable Type:** Univariate  
    **Story:** Most deliveries finish in a few days.
    """)
    plot_hist(df, 'delivery_days', 'Delivery Days (Continuous)', 'Count (Continuous)', 'Delivery Days Distribution')

    # ----------------------------
    # 7️⃣ Customer Age Group Revenue
    # ----------------------------
    st.subheader("7️⃣ Revenue by Age Group")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Compare spending by age group  
    **X-axis:** Age Group (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Identify high-spending customer segments.
    """)
    age = df.groupby('customer_age_group')['final_amount_lakh'].sum().reset_index()
    plot_bar(age, 'customer_age_group', 'final_amount_lakh', 'Age Group (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Revenue by Age Group')

    # ----------------------------
    # 8️⃣ City-wise Revenue (Top 10)
    # ----------------------------
    st.subheader("8️⃣ Top 10 Cities by Revenue")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Identify cities driving revenue  
    **X-axis:** City (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Highlights urban hubs.
    """)
    city = df.groupby('customer_city')['final_amount_lakh'].sum().sort_values(ascending=False).head(10).reset_index()
    plot_bar(city, 'customer_city', 'final_amount_lakh', 'City (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Top 10 Cities by Revenue', rotation=45)

    # ----------------------------
    # 9️⃣ Discount vs Sales
    # ----------------------------
    st.subheader("9️⃣ Discount vs Order Amount")
    st.markdown("""
    **Chart:** Scatter Plot  
    **Purpose:** Examine how discounts impact revenue  
    **X-axis:** Discount % (Continuous)  
    **Y-axis:** Final Amount (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Check if higher discounts boost sales.
    """)
    plot_scatter(df, 'discount_percent', 'final_amount_lakh', 'Discount % (Continuous)', 'Final Amount (₹ Lakh, Continuous)', 'Discount vs Revenue')

    # ----------------------------
    # 10️⃣ Product Ratings vs Sales
    # ----------------------------
    st.subheader("🔟 Product Rating vs Revenue")
    st.markdown("""
    **Chart:** Scatter Plot  
    **Purpose:** See if higher-rated products sell more  
    **X-axis:** Product Rating (Continuous)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** High-rated products often drive more revenue.
    """)
    plot_scatter(df, 'product_rating', 'final_amount_lakh', 'Product Rating (Continuous)', 'Revenue (₹ Lakh, Continuous)', 'Rating vs Revenue')

    # ----------------------------
    # 11️⃣ Quantity Sold Distribution
    # ----------------------------
    st.subheader("11️⃣ Quantity Sold Distribution")
    st.markdown("""
    **Chart:** Histogram  
    **Purpose:** Show distribution of product quantities  
    **X-axis:** Quantity (Continuous)  
    **Y-axis:** Count (Continuous)  
    **Variable Type:** Univariate  
    **Story:** Identify fast-moving SKUs.
    """)
    plot_hist(df, 'quantity', 'Quantity (Continuous)', 'Count (Continuous)', 'Quantity Sold Distribution')

    # ----------------------------
    # 12️⃣ Top Brands by Revenue
    # ----------------------------
    st.subheader("12️⃣ Top 10 Brands by Revenue")
    st.markdown("""
    **Chart:** Horizontal Bar Chart  
    **Purpose:** Identify best-performing brands  
    **X-axis:** Revenue (₹ Lakh, Continuous)  
    **Y-axis:** Brand (Discrete)  
    **Variable Type:** Bivariate  
    **Story:** Brands driving most revenue.
    """)
    brand = df.groupby('brand')['final_amount_lakh'].sum().sort_values(ascending=True).tail(10).reset_index()
    plt.figure(figsize=(8,5))
    sns.barplot(x='final_amount_lakh', y='brand', data=brand, palette='magma')
    plt.xlabel("Revenue (₹ Lakh, Continuous)")
    plt.ylabel("Brand (Discrete)")
    plt.title("Top 10 Brands by Revenue")
    st.pyplot(plt)
    plt.clf()

    # ----------------------------
    # 13️⃣ Delivery Type Analysis
    # ----------------------------
    st.subheader("13️⃣ Delivery Type Revenue")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Compare delivery types (Standard, Express)  
    **X-axis:** Delivery Type (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** See which delivery type generates more revenue.
    """)
    if 'delivery_type' in df.columns:
        delivery = df.groupby('delivery_type')['final_amount_lakh'].sum().reset_index()
        plot_bar(delivery, 'delivery_type', 'final_amount_lakh', 'Delivery Type (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Revenue by Delivery Type')

    # ----------------------------
    # 14️⃣ Festival Sale vs Non-Festival
    # ----------------------------
    st.subheader("14️⃣ Festival Sale Impact")
    st.markdown("""
    **Chart:** Box Plot  
    **Purpose:** Compare order amounts during festival vs non-festival  
    **X-axis:** Festival Sale (Discrete)  
    **Y-axis:** Final Amount (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Festivals boost sales.
    """)
    if 'is_festival_sale' in df.columns:
        plot_box(df, 'is_festival_sale', 'final_amount_lakh', 'Festival Sale (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Festival Sale vs Revenue')

    # ----------------------------
    # 15️⃣ Customer Tier vs Revenue
    # ----------------------------
    st.subheader("15️⃣ Customer Tier Revenue")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Compare revenue across customer tiers  
    **X-axis:** Customer Tier (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Higher-tier customers spend more.
    """)
    if 'customer_tier' in df.columns:
        tier = df.groupby('customer_tier')['final_amount_lakh'].sum().reset_index()
        plot_bar(tier, 'customer_tier', 'final_amount_lakh', 'Customer Tier (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Revenue by Customer Tier')

    # ----------------------------
    # 16️⃣ Return Rate by Category
    # ----------------------------
    st.subheader("16️⃣ Return Rate by Category")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** See return % across categories  
    **X-axis:** Category (Discrete)  
    **Y-axis:** Return Rate (%, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Pinpoint high-return categories for action.
    """)
    if 'return_status' in df.columns:
        df['is_returned'] = df['return_status'].apply(lambda x: 1 if x.lower()=='returned' else 0)
        return_rate = df.groupby('category')['is_returned'].mean().sort_values(ascending=False).reset_index()
        return_rate['return_rate_percent'] = return_rate['is_returned']*100
        plot_bar(return_rate, 'category', 'return_rate_percent', 'Category (Discrete)', 'Return Rate (%)', 'Return Rate by Category', rotation=45)

    # ----------------------------
    # 17️⃣ Product Weight vs Revenue
    # ----------------------------
    st.subheader("17️⃣ Product Weight Impact")
    st.markdown("""
    **Chart:** Scatter Plot  
    **Purpose:** Analyze effect of product weight on revenue  
    **X-axis:** Product Weight (kg, Continuous)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** Heavy products may have lower sales.
    """)
    if 'product_weight_kg' in df.columns:
        plot_scatter(df, 'product_weight_kg', 'final_amount_lakh', 'Weight (kg, Continuous)', 'Revenue (₹ Lakh, Continuous)', 'Weight vs Revenue')

    # ----------------------------
    # 18️⃣ Top 10 Products by Revenue
    # ----------------------------
    st.subheader("18️⃣ Top 10 Products by Revenue")
    st.markdown("""
    **Chart:** Horizontal Bar Chart  
    **Purpose:** Identify top revenue-generating products  
    **X-axis:** Revenue (₹ Lakh, Continuous)  
    **Y-axis:** Product Name (Discrete)  
    **Variable Type:** Bivariate  
    **Story:** Focus inventory on top performers.
    """)
    top_products = df.groupby('product_name')['final_amount_lakh'].sum().sort_values(ascending=True).tail(10).reset_index()
    plt.figure(figsize=(8,5))
    sns.barplot(x='final_amount_lakh', y='product_name', data=top_products, palette='rocket')
    plt.xlabel("Revenue (₹ Lakh, Continuous)")
    plt.ylabel("Product Name (Discrete)")
    plt.title("Top 10 Products by Revenue")
    st.pyplot(plt)
    plt.clf()

    # ----------------------------
    # 19️⃣ Customer Spending Tier vs Revenue
    # ----------------------------
    st.subheader("19️⃣ Customer Spending Tier")
    st.markdown("""
    **Chart:** Bar Chart  
    **Purpose:** Compare revenue by spending tiers  
    **X-axis:** Customer Spending Tier (Discrete)  
    **Y-axis:** Revenue (₹ Lakh, Continuous)  
    **Variable Type:** Bivariate  
    **Story:** High-spending tiers contribute most.
    """)
    if 'customer_spending_tier' in df.columns:
        spend_tier = df.groupby('customer_spending_tier')['final_amount_lakh'].sum().reset_index()
        plot_bar(spend_tier, 'customer_spending_tier', 'final_amount_lakh', 'Spending Tier (Discrete)', 'Revenue (₹ Lakh, Continuous)', 'Revenue by Spending Tier')

    # ----------------------------
    # 20️⃣ Customer Ratings Distribution
    # ----------------------------
    st.subheader("20️⃣ Customer Ratings Distribution")
    st.markdown("""
    **Chart:** Histogram  
    **Purpose:** Analyze distribution of product ratings  
    **X-axis:** Rating (Continuous)  
    **Y-axis:** Count (Continuous)  
    **Variable Type:** Univariate  
    **Story:** Most products are rated positively.
    """)
    plot_hist(df, 'product_rating', 'Product Rating (Continuous)', 'Count (Continuous)', 'Product Rating Distribution')
