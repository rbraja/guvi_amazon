import streamlit as st
import pandas as pd
import numpy as np
import os
import re
from utils import data_cleaning

def detect_currency_symbol(value):
    """Detect currency symbols in strings."""
    if isinstance(value, str) and any(sym in value for sym in ['₹', '$', '€']):
        return True
    return False

def app(csv_path=None):
    st.title("🔍 Modified Data Summary — All CSV Files (Before vs After Cleaning)")

    # -----------------------------
    # Plain-English summary
    # -----------------------------
    st.markdown("""
    This page compares **all CSV files (2015–2025)** in your `data/raw` folder  
    and shows **only modified cells** after cleaning, including:
    - 📂 CSV file name  
    - 🧱 Column name  
    - 🔢 Row number  
    - 🧹 Before & After values  
    - 🧠 Reason for change  
    - 🛠️ Method / Library used

    ### How cleaning happens 
    1. **Load CSV files** using `pandas.read_csv()` (comma-separated, may limit rows for performance)
    2. **Detect columns needing cleaning** (dates, prices, ratings, cities, booleans, categories, delivery info, payment)
    3. **Apply column-specific cleaning**:
        - `order_date` → standardized to `YYYY-MM-DD`
        - `original_price_inr` → remove currency symbols/commas and convert to float
        - `customer_rating` → extract numeric rating
        - `customer_city` → standardize city names
        - `is_prime_member`, `is_prime_eligible`, `is_festival_sale` → convert Yes/No to boolean
        - `product_category` → standardize text
        - `delivery_days` → convert "2-4 days" to numeric average
        - `payment_method` → normalize names
    4. **Compare original vs cleaned data** and record modified cells
    5. **Show results** in table with before/after values, reason, and method/library
    6. **Allow download** of modified data summary as CSV
    """)

    # -----------------------------
    # Read and clean CSV files
    # -----------------------------
    raw_path = "data/raw"
    raw_files = [f for f in os.listdir(raw_path) if f.endswith(".csv")]

    if not raw_files:
        st.warning("⚠️ No CSV files found in `data/raw/` folder.")
        return

    rows_limit = st.slider("📊 Rows to sample per file", 100, 2000, 500, 100)
    all_modified_records = []

    reason_map = {
        "order_date": {"reason": "Standardized date format", "method": "pd.to_datetime (pandas)"},
        "original_price_inr": {"reason": "Removed ₹, $, commas and converted to float", "method": "str.replace + pd.to_numeric"},
        "customer_rating": {"reason": "Extracted numeric value from rating text", "method": "str.extract + pd.to_numeric"},
        "customer_city": {"reason": "Standardized city names", "method": "str.lower/replace"},
        "is_prime_member": {"reason": "Normalized boolean values", "method": "map({'Yes': True, 'No': False})"},
        "is_prime_eligible": {"reason": "Normalized boolean values", "method": "map({'Yes': True, 'No': False})"},
        "is_festival_sale": {"reason": "Normalized boolean values", "method": "map({'Yes': True, 'No': False})"},
        "product_category": {"reason": "Standardized category names", "method": "str.strip + title()"},
        "delivery_days": {"reason": "Converted text (e.g., '2-4 days') to numeric average", "method": "str.extract + mean"},
        "payment_method": {"reason": "Normalized payment names", "method": "str.lower + replace"},
    }

    progress = st.progress(0)
    total_files = len(raw_files)

    for idx, file in enumerate(raw_files, start=1):
        file_path = os.path.join(raw_path, file)
        try:
            df_raw = pd.read_csv(file_path, nrows=rows_limit)
            df_clean = data_cleaning.clean_data(df_raw.copy())

            common_cols = [c for c in df_raw.columns if c in df_clean.columns]
            df_raw = df_raw[common_cols].reset_index(drop=True)
            df_clean = df_clean[common_cols].reset_index(drop=True)

            mask = df_raw.ne(df_clean)
            changed_positions = mask.stack()[mask.stack()].index

            for (i, col) in changed_positions:
                before = df_raw.at[i, col]
                after = df_clean.at[i, col]

                if pd.isna(before) and pd.isna(after):
                    continue
                if str(before).strip() == str(after).strip():
                    continue

                if col == "original_price_inr" and detect_currency_symbol(str(before)):
                    reason = "Removed currency symbols and commas"
                    method_used = "str.replace + pd.to_numeric (pandas)"
                else:
                    entry = reason_map.get(col, {"reason": "General text cleanup", "method": "N/A"})
                    reason = entry["reason"]
                    method_used = entry["method"]

                all_modified_records.append({
                    "CSV File": file,
                    "Row Index": i + 1,
                    "Column": col,
                    "Before Cleaning": before,
                    "After Cleaning": after,
                    "Reason": reason,
                    "Method / Library": method_used
                })

        except Exception as e:
            st.error(f"❌ Error reading or cleaning `{file}`: {e}")

        progress.progress(idx / total_files)

    # -----------------------------
    # Show modified data table
    # -----------------------------
    df_modified = pd.DataFrame(all_modified_records)

    st.subheader("🧾 Modified Data Across All Files")
    if df_modified.empty:
        st.success("✅ No modifications detected in any of the CSV files.")
    else:
        st.write(f"Found **{len(df_modified):,}** modified cells across **{len(raw_files)} files.**")
        st.dataframe(df_modified.head(500), use_container_width=True)

        csv_download = df_modified.to_csv(index=False)
        st.download_button(
            label="⬇️ Download Modified Data Summary (CSV)",
            data=csv_download,
            file_name="modified_data_summary.csv",
            mime="text/csv",
        )

    st.caption("💡 Only shows rows and columns where the cleaned data differs from the original, including reason and method/library used.")
