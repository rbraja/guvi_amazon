import streamlit as st
from utils import db_utils

# ------------------------- Dashboard Queries -------------------------
dashboard_queries = {
    # Executive Dashboard (1-5)
    "1. Executive Summary Dashboard": """
        SELECT SUM(final_amount_inr) AS total_revenue,
               COUNT(DISTINCT customer_id) AS active_customers,
               AVG(final_amount_inr) AS avg_order_value
        FROM transactions;
    """,
    "2. Real-time Business Performance Monitor": """
        SELECT order_year, order_month,
               SUM(final_amount_inr) AS revenue,
               COUNT(DISTINCT customer_id) AS active_customers
        FROM transactions
        GROUP BY order_year, order_month
        ORDER BY order_year DESC, order_month DESC
        LIMIT 5;
    """,
    "3. Strategic Overview Dashboard": """
        SELECT customer_state AS region,
               SUM(final_amount_inr) AS revenue,
               COUNT(DISTINCT customer_id) AS active_customers
        FROM transactions
        GROUP BY customer_state
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "4. Financial Performance Dashboard": """
        SELECT category, SUM(final_amount_inr) AS total_revenue,
               AVG(final_amount_inr) AS avg_order_value
        FROM transactions
        GROUP BY category
        ORDER BY total_revenue DESC
        LIMIT 5;
    """,
    "5. Growth Analytics Dashboard": """
        SELECT order_year, COUNT(DISTINCT customer_id) AS new_customers,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY order_year
        ORDER BY order_year DESC
        LIMIT 5;
    """,
    # Revenue Analytics (6-10)
    "6. Revenue Trend Analysis": """
        SELECT order_year, order_month,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY order_year, order_month
        ORDER BY order_year DESC, order_month DESC
        LIMIT 5;
    """,
    "7. Category Performance Dashboard": """
        SELECT category,
               SUM(final_amount_inr) AS revenue,
               COUNT(DISTINCT product_id) AS products_sold
        FROM transactions
        GROUP BY category
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "8. Geographic Revenue Analysis": """
        SELECT customer_state, customer_city,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY customer_state, customer_city
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "9. Festival Sales Analytics": """
        SELECT festival_name, SUM(final_amount_inr) AS revenue,
               COUNT(DISTINCT customer_id) AS active_customers
        FROM transactions
        WHERE is_festival_sale='Yes'
        GROUP BY festival_name
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "10. Price Optimization Dashboard": """
        SELECT product_id, AVG(discounted_price_inr) AS avg_price,
               AVG(discount_percent) AS avg_discount, SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY product_id
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    # Customer Analytics (11-15)
    "11. Customer Segmentation": """
        SELECT customer_spending_tier, COUNT(DISTINCT customer_id) AS customers,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY customer_spending_tier
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "12. Customer Journey Analytics": """
        SELECT customer_id, MIN(order_date) AS first_order, MAX(order_date) AS last_order,
               COUNT(transaction_id) AS total_orders
        FROM transactions
        GROUP BY customer_id
        ORDER BY total_orders DESC
        LIMIT 5;
    """,
    "13. Prime Membership Analytics": """
        SELECT is_prime_member, COUNT(DISTINCT customer_id) AS customers,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY is_prime_member
        LIMIT 5;
    """,
    "14. Customer Retention Dashboard": """
        SELECT order_year, customer_tier, COUNT(DISTINCT customer_id) AS active_customers
        FROM transactions
        GROUP BY order_year, customer_tier
        ORDER BY order_year DESC
        LIMIT 5;
    """,
    "15. Demographics & Behavior Dashboard": """
        SELECT customer_age_group, COUNT(DISTINCT customer_id) AS customers,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY customer_age_group
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    # Product & Inventory Analytics (16-20)
    "16. Product Performance Dashboard": """
        SELECT product_id, product_name, SUM(final_amount_inr) AS revenue,
               COUNT(quantity) AS units_sold
        FROM transactions
        GROUP BY product_id, product_name
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "17. Brand Analytics Dashboard": """
        SELECT brand, SUM(final_amount_inr) AS revenue,
               COUNT(DISTINCT product_id) AS products_sold
        FROM transactions
        GROUP BY brand
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "18. Inventory Optimization Dashboard": """
        SELECT product_id, SUM(quantity) AS total_units_sold, AVG(product_weight_kg) AS avg_weight
        FROM transactions
        GROUP BY product_id
        ORDER BY total_units_sold DESC
        LIMIT 5;
    """,
    "19. Product Rating & Review Dashboard": """
        SELECT product_id, AVG(product_rating) AS avg_rating,
               COUNT(customer_rating) AS review_count
        FROM transactions
        GROUP BY product_id
        ORDER BY avg_rating DESC
        LIMIT 5;
    """,
    "20. New Product Launch Dashboard": """
        SELECT product_id, MIN(order_date) AS launch_date,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY product_id
        ORDER BY launch_date DESC
        LIMIT 5;
    """,
    # Operations & Logistics (21-25)
    "21. Delivery Performance Dashboard": """
        SELECT delivery_type, AVG(delivery_days) AS avg_delivery_days,
               COUNT(*) AS orders
        FROM transactions
        GROUP BY delivery_type
        ORDER BY avg_delivery_days ASC
        LIMIT 5;
    """,
    "22. Payment Analytics Dashboard": """
        SELECT payment_method, COUNT(*) AS total_transactions,
               SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY payment_method
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "23. Return & Cancellation Dashboard": """
        SELECT return_status, COUNT(*) AS total_returns,
               SUM(final_amount_inr) AS revenue_lost
        FROM transactions
        GROUP BY return_status
        ORDER BY revenue_lost DESC
        LIMIT 5;
    """,
    "24. Customer Service Dashboard": """
        SELECT customer_tier, COUNT(*) AS total_orders, AVG(delivery_days) AS avg_delivery_days
        FROM transactions
        GROUP BY customer_tier
        ORDER BY total_orders DESC
        LIMIT 5;
    """,
    "25. Supply Chain Dashboard": """
        SELECT product_id, SUM(quantity) AS units_sold, AVG(delivery_days) AS avg_delivery_days
        FROM transactions
        GROUP BY product_id
        ORDER BY units_sold DESC
        LIMIT 5;
    """,
    # Advanced Analytics (26-30)
    "26. Predictive Analytics Dashboard": """
        SELECT order_year, order_month, SUM(final_amount_inr) AS revenue
        FROM transactions
        GROUP BY order_year, order_month
        ORDER BY order_year DESC, order_month DESC
        LIMIT 5;
    """,
    "27. Market Intelligence Dashboard": """
        SELECT category, SUM(final_amount_inr) AS revenue, COUNT(DISTINCT product_id) AS products
        FROM transactions
        GROUP BY category
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "28. Cross-selling & Upselling Dashboard": """
        SELECT product_id, COUNT(DISTINCT customer_id) AS customer_count
        FROM transactions
        GROUP BY product_id
        ORDER BY customer_count DESC
        LIMIT 5;
    """,
    "29. Seasonal Planning Dashboard": """
        SELECT order_month, SUM(final_amount_inr) AS revenue, COUNT(DISTINCT customer_id) AS active_customers
        FROM transactions
        GROUP BY order_month
        ORDER BY revenue DESC
        LIMIT 5;
    """,
    "30. Business Intelligence Command Center": """
        SELECT 'Dashboard Overview' AS metric, COUNT(*) AS total_orders, SUM(final_amount_inr) AS total_revenue
        FROM transactions
        LIMIT 5;
    """
}

# ------------------------- Streamlit App -------------------------
def app(_=None):
    st.title("📊 Analytics Dashboard Queries")
    st.write("Select a query from the dropdown to view the top 5 rows of the result and the SQL query.")

    # Dropdown for all queries
    selected_query_name = st.selectbox("Choose Dashboard Query", list(dashboard_queries.keys()))
    query = dashboard_queries[selected_query_name]

    st.subheader(selected_query_name)
    st.code(query, language="sql")

    # Run query and display
    df = db_utils.run_query(query)
    if not df.empty:
        st.dataframe(df.head(5))
    else:
        st.write("No data returned.")
